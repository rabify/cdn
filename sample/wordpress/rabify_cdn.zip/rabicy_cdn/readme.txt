=== rabify CDN ===
Contributors: rdlabo
Tags: image, resize
Requires at least: 4.9.6
Tested up to: 4.9.6
Requires PHP: 7.0
Stable tag: 0.0.1
License: GPL2

This plugin replaced image domain for using service of `rabify CDN` and setting.

== Description ==

This plugin replace image domain for using service of `rabify CDN` and setting.
1. replace domain
2. remove default srcset and sizes added by WordPress.
3. add srcset and sizes

= How to use =

1. Settings -> Media
2. Check "rabify CDN" fields
3. Update settings

== Installation ==

1. Upload `rabify-cdn` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 0.0.1 =
* first release.